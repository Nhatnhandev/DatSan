﻿using DatSan.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DatSan.Controllers
{
    public class DatHangController : Controller
    {
        // GET: DatHang
        DataClasses1DataContext data = new DataClasses1DataContext();
        public ActionResult Index()
        {
            return View();
        }

    }
}